﻿namespace SistemaEmpleados
{
    partial class frmSistemaEmpleados
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.sistemaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acercaDeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.salirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.empleadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.agregarNuevoEmpleadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripSeparator();
            this.listadoGeneralDeEmpleadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoDeEnokeadisDeUnaCategoriaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.listadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripSeparator();
            this.consultaDeDatosDeUnEmpleadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.busquedaDeUnEmpleadoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sistemaToolStripMenuItem,
            this.empleadoToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(850, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // sistemaToolStripMenuItem
            // 
            this.sistemaToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.acercaDeToolStripMenuItem,
            this.toolStripMenuItem1,
            this.salirToolStripMenuItem});
            this.sistemaToolStripMenuItem.Name = "sistemaToolStripMenuItem";
            this.sistemaToolStripMenuItem.Size = new System.Drawing.Size(60, 22);
            this.sistemaToolStripMenuItem.Text = "Sistema";
            // 
            // acercaDeToolStripMenuItem
            // 
            this.acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
            this.acercaDeToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.acercaDeToolStripMenuItem.Text = "Acerca de...";
            this.acercaDeToolStripMenuItem.Click += new System.EventHandler(this.acercaDeToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(132, 6);
            // 
            // salirToolStripMenuItem
            // 
            this.salirToolStripMenuItem.Name = "salirToolStripMenuItem";
            this.salirToolStripMenuItem.Size = new System.Drawing.Size(135, 22);
            this.salirToolStripMenuItem.Text = "Salir";
            this.salirToolStripMenuItem.Click += new System.EventHandler(this.salirToolStripMenuItem_Click);
            // 
            // empleadoToolStripMenuItem
            // 
            this.empleadoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.agregarNuevoEmpleadoToolStripMenuItem,
            this.toolStripMenuItem2,
            this.listadoGeneralDeEmpleadoToolStripMenuItem,
            this.listadoDeEnokeadisDeUnaCategoriaToolStripMenuItem,
            this.listadoToolStripMenuItem,
            this.toolStripMenuItem3,
            this.consultaDeDatosDeUnEmpleadoToolStripMenuItem,
            this.busquedaDeUnEmpleadoToolStripMenuItem});
            this.empleadoToolStripMenuItem.Name = "empleadoToolStripMenuItem";
            this.empleadoToolStripMenuItem.Size = new System.Drawing.Size(72, 22);
            this.empleadoToolStripMenuItem.Text = "Empleado";
            // 
            // agregarNuevoEmpleadoToolStripMenuItem
            // 
            this.agregarNuevoEmpleadoToolStripMenuItem.Name = "agregarNuevoEmpleadoToolStripMenuItem";
            this.agregarNuevoEmpleadoToolStripMenuItem.Size = new System.Drawing.Size(305, 22);
            this.agregarNuevoEmpleadoToolStripMenuItem.Text = "Agregar nuevo empleado..";
            this.agregarNuevoEmpleadoToolStripMenuItem.Click += new System.EventHandler(this.agregarNuevoEmpleadoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(302, 6);
            // 
            // listadoGeneralDeEmpleadoToolStripMenuItem
            // 
            this.listadoGeneralDeEmpleadoToolStripMenuItem.Name = "listadoGeneralDeEmpleadoToolStripMenuItem";
            this.listadoGeneralDeEmpleadoToolStripMenuItem.Size = new System.Drawing.Size(305, 22);
            this.listadoGeneralDeEmpleadoToolStripMenuItem.Text = "Listado general de empleado..";
            this.listadoGeneralDeEmpleadoToolStripMenuItem.Click += new System.EventHandler(this.listadoGeneralDeEmpleadoToolStripMenuItem_Click);
            // 
            // listadoDeEnokeadisDeUnaCategoriaToolStripMenuItem
            // 
            this.listadoDeEnokeadisDeUnaCategoriaToolStripMenuItem.Name = "listadoDeEnokeadisDeUnaCategoriaToolStripMenuItem";
            this.listadoDeEnokeadisDeUnaCategoriaToolStripMenuItem.Size = new System.Drawing.Size(305, 22);
            this.listadoDeEnokeadisDeUnaCategoriaToolStripMenuItem.Text = "Listado de empleados de una categoria...";
            this.listadoDeEnokeadisDeUnaCategoriaToolStripMenuItem.Click += new System.EventHandler(this.listadoDeEnokeadisDeUnaCategoriaToolStripMenuItem_Click);
            // 
            // listadoToolStripMenuItem
            // 
            this.listadoToolStripMenuItem.Name = "listadoToolStripMenuItem";
            this.listadoToolStripMenuItem.Size = new System.Drawing.Size(305, 22);
            this.listadoToolStripMenuItem.Text = "Listado de empleados con sueldo mayor a...";
            this.listadoToolStripMenuItem.Click += new System.EventHandler(this.listadoToolStripMenuItem_Click);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(302, 6);
            // 
            // consultaDeDatosDeUnEmpleadoToolStripMenuItem
            // 
            this.consultaDeDatosDeUnEmpleadoToolStripMenuItem.Name = "consultaDeDatosDeUnEmpleadoToolStripMenuItem";
            this.consultaDeDatosDeUnEmpleadoToolStripMenuItem.Size = new System.Drawing.Size(305, 22);
            this.consultaDeDatosDeUnEmpleadoToolStripMenuItem.Text = "Consulta de datos de un empleado...";
            this.consultaDeDatosDeUnEmpleadoToolStripMenuItem.Click += new System.EventHandler(this.consultaDeDatosDeUnEmpleadoToolStripMenuItem_Click);
            // 
            // busquedaDeUnEmpleadoToolStripMenuItem
            // 
            this.busquedaDeUnEmpleadoToolStripMenuItem.Name = "busquedaDeUnEmpleadoToolStripMenuItem";
            this.busquedaDeUnEmpleadoToolStripMenuItem.Size = new System.Drawing.Size(305, 22);
            this.busquedaDeUnEmpleadoToolStripMenuItem.Text = "Busqueda de un empleado...";
            this.busquedaDeUnEmpleadoToolStripMenuItem.Click += new System.EventHandler(this.busquedaDeUnEmpleadoToolStripMenuItem_Click);
            // 
            // frmSistemaEmpleados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(850, 415);
            this.Controls.Add(this.menuStrip1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "frmSistemaEmpleados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Sistema de Empleados";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmSistemaEmpleados_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem sistemaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem acercaDeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem salirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem empleadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem agregarNuevoEmpleadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem listadoGeneralDeEmpleadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoDeEnokeadisDeUnaCategoriaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem listadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem consultaDeDatosDeUnEmpleadoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem busquedaDeUnEmpleadoToolStripMenuItem;
    }
}

